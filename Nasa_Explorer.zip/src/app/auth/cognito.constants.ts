// URL de la API de Cognito para solicitudes HTTP directas
export const COGNITO_URL =
  'https://cognito-idp.us-east-2.amazonaws.com/';

// Identificador del cliente de aplicación
export const COGNITO_CLIENT_ID =
  '15kgev445afv48084b5q26fed1';

// Encabezados para solicitudes HTTP a la API de Cognito
export const COGNITO_HEADERS = {
  'Content-Type': 'application/x-amz-json-1.1'
};

// Clave para almacenar la sesión en el navegador
export const STORAGE_KEYS = {
  SESION: 'nasa_explorer_sesion'
};

